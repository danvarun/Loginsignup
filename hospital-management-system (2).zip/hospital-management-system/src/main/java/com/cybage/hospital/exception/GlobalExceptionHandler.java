package com.cybage.hospital.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	

	@ExceptionHandler(EmailAlreadyExistException.class)
	public ResponseEntity<String> emailAlreadyExist(EmailAlreadyExistException exception){
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.BAD_GATEWAY);  
	}
	@ExceptionHandler(WrongOtpException.class)
	public ResponseEntity<String> wrongOtpException(WrongOtpException exception){
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.UNAUTHORIZED);  
	}
	@ExceptionHandler(AccountBlockedException.class)
	public ResponseEntity<String> accountLockedException(AccountBlockedException exception){
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.LOCKED);  
	}
	@ExceptionHandler(InvalidCredentialsException.class)
	public ResponseEntity<String> invalidCredentialsException(InvalidCredentialsException exception){
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.UNAUTHORIZED);  
	}
}
