package com.cybage.hospital.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.hospital.EntityDtoConvertor.UserMapper;
import com.cybage.hospital.dto.LoginDto;
import com.cybage.hospital.dto.UserDto;
import com.cybage.hospital.entities.OtpValidationRequest;
import com.cybage.hospital.entities.User;
import com.cybage.hospital.exception.AccountBlockedException;
import com.cybage.hospital.exception.WrongOtpException;
import com.cybage.hospital.services.LoginAttemptService;
import com.cybage.hospital.services.LoginService;
import com.cybage.hospital.services.RegistrationService;

@RestController
@RequestMapping("/api/user/")
public class UserController {
	
    @Autowired
    private  RegistrationService userService;
    @Autowired
	private LoginAttemptService loginAttemptService;
	@Autowired
	private LoginService loginService;
	@Autowired
	private UserMapper userMapper;
	
    
	@PostMapping(path ="register")
	public String register(@RequestBody UserDto userDto) {
		
		return userService.register(userDto);
	}

	@GetMapping(path = "confirm/{token}")
	public String confirm(@PathVariable String  token) {
		   
		return userService.confirmToken( token);
	}
	
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody LoginDto loginRequest)   {
		
			if(loginAttemptService.isBlocked(loginRequest.getEmail()))
			{
				userService.lockAccount(loginRequest.getEmail());
				throw new AccountBlockedException("Your Account is Locked");
			}
			
			
		return new ResponseEntity<String>(loginService.login(loginRequest), HttpStatus.OK);
		
	}
	
	@PostMapping("/validateOtp")
	public ResponseEntity<?> validateOtp(@RequestBody OtpValidationRequest validationRequest) {
		String email = validationRequest.getEmail();
		int otp = validationRequest.getOtp();
		
		Boolean isValidOtp=loginService.validateOtp(email,otp);
		if(isValidOtp)
		{
			
		User user=	userService.findByEmail(email);
		
		return ResponseEntity.ok(userMapper.toUserDto(user));
		}
		else
			throw new WrongOtpException("Wrong Otp Entered...Try Again..!!");
		
	}

}
