package com.cybage.hospital.EntityDtoConvertor;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cybage.hospital.dto.UserDto;
import com.cybage.hospital.entities.User;


@Component
public class UserMapper {
	@Autowired
	ModelMapper mapper ;
	public UserDto toUserDto(User user)
	{    
		UserDto userDto=mapper.map(user, UserDto.class);
		return userDto;
	
	}
	public User toUserEntity(UserDto requestDto)
	{
		User user=	mapper.map(requestDto, User.class);
		return user;
	}

}
