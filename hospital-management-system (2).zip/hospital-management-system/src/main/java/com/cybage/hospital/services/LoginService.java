package com.cybage.hospital.services;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.hospital.daos.UserRepository;
import com.cybage.hospital.dto.LoginDto;
import com.cybage.hospital.email.EmailSender;
import com.cybage.hospital.entities.User;
import com.cybage.hospital.exception.InvalidCredentialsException;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

@Service
public class LoginService {

	private static final Integer EXPIRE_MINS = 5;
	// cache based on username
	private LoadingCache<String, Integer> otpCache;
	@Autowired
	private LoginAttemptService loginAttemptService;

	@Autowired
	private EmailSender emailSender;
	@Autowired
	private UserRepository userRepository;


	public LoginService() {
		super();
		otpCache = CacheBuilder.newBuilder().expireAfterWrite(EXPIRE_MINS, TimeUnit.MINUTES)
				.build(new CacheLoader<String, Integer>() {
					public Integer load(String key) {
						return 0;
					}
				});
	}

	public String login(LoginDto loginRequest) {
        User user=userRepository.findByEmailAndPassword(loginRequest.getEmail(), loginRequest.getPassword());
	        if(user==null)
	        {   loginAttemptService.loginFailed(loginRequest.getEmail());
	        	throw new InvalidCredentialsException("Invalid Credentials..!!");
	        }
        loginAttemptService.loginSucceeded(loginRequest.getEmail());
		String otpMessage = loginUser(loginRequest.getEmail(), loginRequest.getPassword());

		return otpMessage;
	}

	public String loginUser(String email, String password) {

		int otp = generateOTP(email);

		// SEND EMAIL
		String subject = "Verify OTP for Login";
		emailSender.send(subject, email, buildEmail(otp));
		return "OTP is :" + otp;

	}

	private String buildEmail(int otp) {

		return "<div style=\"Margin:0 0 20px 0;font-size:19px;line-height:25px;color:#0b0c0c\"><p>Hello,</p><p style=\"Margin:0 0 20px 0;font-size:19px;line-height:25px;color:#0b0c0c\">  One Time Password for Log-in into Hotel management system  is :<blockquote style=\"Margin:0 0 20px 0;border-left:10px solid #b1b4b6;padding:15px 0 0.1px 15px;font-size:19px;line-height:25px\"><p style=\"Margin:0 0 20px 0;font-size:19px;line-height:25px;color:#0b0c0c\">"
				+ otp
				+ "</p></blockquote></p>\n OTP will expire in 5 minutes<p><b>Thank you <br/>Team-Hotel management system</b><p/></div>";

	}

	// This method is used to push the opt number against Key. Rewrite the OTP if it
	// exists
	// Using user email as key
	public int generateOTP(String key) {

		Random random = new Random();
		int otp = 100000 + random.nextInt(900000);
		otpCache.put(key, otp);
		return otp;
	}

	// This method is used to return the OPT number against Key->Key values is
	// username
	public int getOtp(String key) {
		try {
			return otpCache.get(key);
		} catch (Exception e) {
			return 0;
		}
	}

	// This method is used to clear the OTP catched already
	public void clearOTP(String key) {
		otpCache.invalidate(key);
	}

	public Boolean validateOtp(String email, int otp) {

		int serverOtp = getOtp(email);

		if (otp == serverOtp) {
			clearOTP(email);
			return true; // SUCCESS;
		} else {
			return false; // FAIL;
		}

	}

	
}
