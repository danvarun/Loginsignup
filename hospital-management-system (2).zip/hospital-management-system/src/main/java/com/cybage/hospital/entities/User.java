package com.cybage.hospital.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

@Entity
@Table
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@NotBlank
	@NotNull
	@Column
	private String firstname;
	@NotBlank
	@NotNull
	@Column
	private String lastName;
	@Email
	@NotNull
	@Column
	private String email;
	@NotBlank
	@NotNull
	@Column
	private String password;
	@NotNull
	@Column
	private Date dob;
	@NotBlank
	@NotNull
	@Column
	private String gender;
	@Positive
	@NotNull
	@Column
	private Long mobileNumber;

	@Enumerated(EnumType.STRING)
	@NotNull
	private UserRole UserRole;
	
	private boolean isLocked = false;
	
	private boolean isEnabled = false;

	public User() {
		super();

	}

	public User(int userId, String firstname, String lastName, String email, String password, Date dob, String gender,
			Long mobileNumber, com.cybage.hospital.entities.UserRole userRole, boolean isLocked, boolean isEnabled) {
		super();
		this.id = userId;
		this.firstname = firstname;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.dob = dob;
		this.gender = gender;
		this.mobileNumber = mobileNumber;
		UserRole = userRole;
		this.isLocked = isLocked;
		this.isEnabled = isEnabled;
	}

	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public UserRole getUserRole() {
		return UserRole;
	}

	public void setUserRole(UserRole userRole) {
		UserRole = userRole;
	}

	public boolean isLocked() {
		return isLocked;
	}

	public void setLocked(boolean isLocked) {
		this.isLocked = isLocked;
	}

	public boolean isEnabled() {
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	@Override
	public String toString() {
		return "User [userId=" + id + ", firstname=" + firstname + ", lastName=" + lastName + ", email=" + email
				+ ", password=" + password + ", dob=" + dob + ", gender=" + gender + ", mobileNumber=" + mobileNumber
				+ ", UserRole=" + UserRole + ", isLocked=" + isLocked + ", isEnabled=" + isEnabled + "]";
	}

}
