package com.cybage.hospital.services;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cybage.hospital.EntityDtoConvertor.UserMapper;
import com.cybage.hospital.daos.UserRepository;
import com.cybage.hospital.dto.UserDto;
import com.cybage.hospital.email.EmailSender;
import com.cybage.hospital.entities.ConfirmationToken;
import com.cybage.hospital.entities.User;
import com.cybage.hospital.entities.UserRole;
import com.cybage.hospital.exception.EmailAlreadyExistException;

@Service
public class RegistrationService {
	private static final Integer EXPIRE_MINS = 15;

	private final static String USER_NOT_FOUND_MSG = "user with email %s not found";
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ConfirmationTokenService confirmationTokenService;
	
	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private EmailSender emailSender;
	

	public String register(UserDto userDto) {

		userRepository.deleteUnconfimedUsers();
		userRepository.deleteUnconfimedUsersfromAppUsers();

		// Boolean isuserExist =
		// userRepository.findByEmail(user.getEmail()).isPresent();
		User user1 = userRepository.findByEmail(userDto.getEmail());

		if (user1 != null) {
			// check of attributes are the same and
			// if email not confirmed send confirmation email.
			// return "email already taken";
			throw new EmailAlreadyExistException("Email Already Registred");

		}
	User user=	userMapper.toUserEntity(userDto);
	user.setUserRole(UserRole.ROLE_PATIENT);
		userRepository.save(user);

		String token = UUID.randomUUID().toString();

		ConfirmationToken confirmationToken = new ConfirmationToken(token, LocalDateTime.now(),
				LocalDateTime.now().plusMinutes(15), user);

		confirmationTokenService.saveConfirmationToken(confirmationToken);
 
		
		String link = "172.27.95.71:8091/api/user/confirm/"+ token;

		// Below code send the mail
		emailSender.send("Confirm your email for registration", userDto.getEmail(),
				buildEmail(userDto.getfirstName(), link));
		
		return token;
	}
	

	@Transactional
	public String confirmToken(String token) {
		ConfirmationToken confirmationToken = confirmationTokenService.getToken(token)
				.orElseThrow(() -> new IllegalStateException("token not found"));

		if (confirmationToken.getConfirmedAt() != null) {
			throw new IllegalStateException("email already confirmed");
		}

		LocalDateTime expiredAt = confirmationToken.getExpiresAt();

		if (expiredAt.isBefore(LocalDateTime.now())) {
			throw new IllegalStateException("token expired");
		}

		confirmationTokenService.setConfirmedAt(token);
		enableUser(confirmationToken.getUser().getEmail());
		return "Your Registration has Been Suceesfully Confirmed, Now you can login using your credentials ";
		}
	
	private String buildEmail(String name, String link) {

		return "<div style=\"Margin:0 0 20px 0;font-size:19px;line-height:25px;color:#0b0c0c\"><p>Hello " + name
				+ ",</p><p style=\"Margin:0 0 20px 0;font-size:19px;line-height:25px;color:#0b0c0c\"> Thank you for registering. Please click on the below link to activate your account: </p><blockquote style=\"Margin:0 0 20px 0;border-left:10px solid #b1b4b6;padding:15px 0 0.1px 15px;font-size:19px;line-height:25px\"><p style=\"Margin:0 0 20px 0;font-size:19px;line-height:25px;color:#0b0c0c\"> <a href=\""
				+ link
				+ "\">Activate your account</a> </p></blockquote>\n Link will expire in 15 minutes.<p><b>Team-Hosiptal management system</b></p></div>";

	}
	 
	public int enableUser(String email) {
		return userRepository.enableUser(email);
	}


	public void lockAccount(String email) {
		
		userRepository.lockUser(email);
	}

	public User findByEmail(String username) {
		User user=	userRepository.findByEmail(username);
			return user;
		}
	


}
