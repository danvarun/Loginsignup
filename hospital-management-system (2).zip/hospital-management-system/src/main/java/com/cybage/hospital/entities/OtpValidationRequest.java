package com.cybage.hospital.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OtpValidationRequest {
   private int otp;
   private String email;
}
