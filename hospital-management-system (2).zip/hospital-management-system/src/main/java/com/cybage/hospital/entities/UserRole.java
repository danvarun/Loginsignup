package com.cybage.hospital.entities;


public enum UserRole {
    ROLE_PATIENT,
    ROLE_ADMIN,
    ROLE_DOCTOR
}
