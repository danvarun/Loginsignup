package com.cybage.hospital.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.cybage.hospital.entities.UserRole;

public class UserDto {
 
	private String id;
	private String firstName;
	
	private String lastName;
	
	private String email;
	
	private String password;
	
	private Date dob;
	
	private String gender;
	
	private Long mobileNumber;

	
	

	public UserDto() {
		super();
		// TODO Auto-generated constructor stub
	}



	public UserDto(String id, String firstName, String lastName, String email, String password, Date dob, String gender,
			Long mobileNumber) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.dob = dob;
		this.gender = gender;
		this.mobileNumber = mobileNumber;
	}



	public String getfirstName() {
		return firstName;
	}

	public void setfirstName(String firstname) {
		this.firstName = firstname;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	
	
}
