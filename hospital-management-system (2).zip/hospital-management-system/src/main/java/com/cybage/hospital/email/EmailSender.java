package com.cybage.hospital.email;

public interface EmailSender {
    void send(String subject,String to, String email);
}
